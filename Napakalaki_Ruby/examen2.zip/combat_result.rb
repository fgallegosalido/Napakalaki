#encoding: utf-8

module NapakalakiGame
  module TreasureKind
    WINGAME = :wingame
    WIN = :win
    LOSE = :lose
  end
end
