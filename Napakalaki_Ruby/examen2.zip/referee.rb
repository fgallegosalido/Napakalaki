#encoding: utf-8

module NapakalakiGame
  class Referee
    @@instance = Array.new

    private_class_method :new

    def initialize
    end

    def self.getInstance (i)
      if @@instance.length == 0
        contador = 0
        5.times do |i|
          @@instance[contador] = Referee.new
          contador += 1
        end
      end
      if i < 5
        @@instance[i]
      else
        nil
      end
    end

    def nextNumber
      [*7..13].sample
      #rand(6) + 1
    end
  end
end
